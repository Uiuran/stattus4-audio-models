# Stattus4
Devs para a stattus4

##Spectral Filtering

- Simple one based on mean mass of spectral frequencies.
- General Spectral Filtering function that allows to determines which statistics to base your filtering and to choose general Frequency-Time projection.
